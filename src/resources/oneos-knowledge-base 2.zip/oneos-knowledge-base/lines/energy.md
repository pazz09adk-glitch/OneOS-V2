# 能源业务条线

**闭环一句话**：供应商与站点建档 → 签约站订单/PLC 或非签约补录 → 对账 → 氢费账户与财务核销回写已付款。

## 责任部门

能源部（主）、财务（核销）、运维/业务（车辆侧核对）。

## 标准步骤

1. **供应商管理**：结算要素与资质。
2. **加氢站管理**：签约站 vs 非签约站；账号与预付款。
3. **加氢订单**：签约站主动上报 / PLC；可含预约。
4. **车辆氢费明细**：非签约站人工补录（OCR/围栏辅助）。
5. **氢费账户 / 收款**：对账单关联收款记录，回写已付款。

## 模块索引

| 模块 | 规则卡 | 置信度 |
|------|--------|--------|
| 供应商管理 | [supplier-management](../modules/supplier-management.md) | architecture |
| 加氢站 | [oneos-web-h2-station-site](../modules/oneos-web-h2-station-site.md) | architecture |
| 加氢订单 H5 | [oneos-h5-h2-order](../modules/oneos-h5-h2-order.md) | architecture |
| 车辆氢费明细 | [vehicle-h2-fee-ledger](../modules/vehicle-h2-fee-ledger.md) | architecture |
| 收款记录/氢费账户 | [payment-records](../modules/payment-records.md) | architecture |

## 与底座

能源成本回填条线盈亏；加氢记录关联车辆档案。

## V1.2 / ONE-OS 补充

| 模块 | 规则卡 |
|------|--------|
| 氢费采购端汇总 | [ledger-h2-procurement-summary](../modules/ledger-h2-procurement-summary.md) |
| 加氢站大屏 | [h2-station-dashboard](../modules/h2-station-dashboard.md) |
