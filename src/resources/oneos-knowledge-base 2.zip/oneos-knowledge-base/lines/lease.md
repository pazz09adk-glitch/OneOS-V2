# 租赁业务条线

**闭环一句话**：客户准入评级 → 标准模板签约 → 提车应收对齐 → 交车与周期台账 → 还车多部门会签结算归档。

## 责任部门

业务管理组（主）、法务、财务、运维（交还车）、安全/能源（还车费用会签）。

## 标准步骤

1. **客户管理**：维护客户；法务/财务/安全综合准入（标准 / 非标 / 禁止签约）。
2. **标准合同模板**：锁定区与风控红线；非标触达审批。
3. **租赁合同**：标准路径直接电子合同；非标/禁止走审批或拦截。
4. **提车应收**：应收与实收匹配，触发运维交车任务。
5. **租赁业务台账**：周期账单、溢出款抵扣下期。
6. **还车应结**：运维还车后多部门费用会签，关联收付款，归档。

## 模块索引

| 模块 | 规则卡 | 置信度 |
|------|--------|--------|
| 客户管理 | [customer-management](../modules/customer-management.md) | architecture |
| 标准合同模板 | [contract-template-management](../modules/contract-template-management.md) | architecture |
| 租赁合同 | [lease-contract-management](../modules/lease-contract-management.md) | confirmed |
| 提车应收 | [vehicle-pickup-receivable](../modules/vehicle-pickup-receivable.md) | architecture |
| 租赁业务台账 | [lease-business-ledger](../modules/lease-business-ledger.md) | architecture |
| 还车应结 | [vehicle-return-settlement](../modules/vehicle-return-settlement.md) | confirmed |

## 与底座

写入车辆履约态、里程相关节点；首期与周期账单关联收款记录。
